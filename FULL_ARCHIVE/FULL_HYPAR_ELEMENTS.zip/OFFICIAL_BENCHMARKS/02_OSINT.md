# OSINT Benchmark — HYPAR_ELEMENTS

**Upstream:** https://github.com/hypar-io/hypar-elements

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.

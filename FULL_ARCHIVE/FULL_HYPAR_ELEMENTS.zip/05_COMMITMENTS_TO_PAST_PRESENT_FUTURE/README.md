# 05 Commitments To Past Present Future

**Project:** HYPAR_ELEMENTS
**Upstream:** https://github.com/hypar-io/hypar-elements

Content specific to HYPAR_ELEMENTS in category ARCHITECTURAL_DESIGN.
